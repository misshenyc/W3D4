const Util = require("./util.js");
const MovingObject = require("./moving_object.js");

function Asteroid(options){
    options = options || {};
    options.color = 'red';
    options.radius = 20;
    options.pos = options.pos || [0,0]  //options.game.randomPosition;
    options.vel = Util.randomVec(10); //need to update number argument
    MovingObject.call(this, options);
}

Util.inherits(Asteroid, MovingObject);


module.exports = Asteroid;


