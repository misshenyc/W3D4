function GameView(game, ctx) {
    this.game = game;
    this.ctx = ctx;
};

GameView.prototype.start = function() {
   const game = this.game;
   game.draw(this.ctx);
//    debugger
//    setInterval(game.moveObjects.bind(game), 20);
//    setInterval(game.draw.bind(game,this.ctx), 20);
};

module.exports = GameView;