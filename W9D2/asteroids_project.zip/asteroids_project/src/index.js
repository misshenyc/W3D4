console.log('Webpack is working!')
const MovingObject = require("./moving_object.js");
const Asteroid = require("./asteroid.js");
const Game = require("./game.js");
const GameView = require("./game_view.js");

// remove 5 and 6 later on
window.MovingObject = MovingObject;
window.Asteroid = Asteroid;

document.addEventListener("DOMContentLoaded", function () {
    const canvasEl = document.getElementById("game-canvas");
    // May have to add height and width later on
    canvasEl.width = Game.DIM_X;
    canvasEl.height = Game.DIM_Y;
    debugger;
    const ctx = canvasEl.getContext("2d");

    const mo = new MovingObject({
        pos: [30, 30],
        vel: [10, 10],
        radius: 5,
        color: "#00FF00"
    });

    mo.draw(ctx)

    // const asteroid = new Asteroid({ pos: [30, 30] });

    const game = new Game();
    // game.addAsteroids();
    // game.moveObjects();

    const game_view = new GameView(game, ctx);
    game_view.start();
})

