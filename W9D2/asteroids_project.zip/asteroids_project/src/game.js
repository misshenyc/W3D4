const Asteroid = require("./asteroid.js");

function Game() {
    this.NUM_ASTEROIDS = 10;
    this.asteroids = [];
    this.addAsteroids();
}

Game.DIM_X = 1000;
Game.DIM_Y = 800;

Game.prototype.randomPosition = function() {
    return [
        this.DIM_X * Math.random(),
        this.DIM_Y * Math.random()
    ];
};

Game.prototype.addAsteroids = function() {
    let count = 0;
    while (count < this.NUM_ASTEROIDS){
        // debugger
        this.asteroids.push(new Asteroid(this))
        count ++;
    };
};

Game.prototype.draw = function(ctx) {
    // debugger;
    ctx.clearRect(0, 0, this.DIM_X, this.DIM_Y);
    // debugger;
    this.asteroids.forEach ( asteroid => asteroid.draw(ctx));
};

Game.prototype.moveObjects = function() {
    // debugger
    this.asteroids.forEach ( asteroid => asteroid.move());
}


module.exports = Game;