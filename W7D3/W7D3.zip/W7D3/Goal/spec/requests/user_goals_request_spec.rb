require 'rails_helper'

RSpec.describe "UserGoals", type: :request do

end
