module UserGoalsHelper
end
