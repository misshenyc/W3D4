// const readline = require('readline');
// const reader = readline.createInterface({
//     input: process.stdin,
//     output: process.stdout
// });

// function askIfGreaterThan(el1, el2, callback) {
//     reader.question(`Is ${el1} greater than ${el2}?`, function (reply) {
//         if (reply === 'yes') {
//             callback(true);
//         }
//         else {
//             callback(false);
//             reader.close();
//         }
//     });
// }

// askIfGreaterThan(4, 2, console.log);

console.log("hello world")